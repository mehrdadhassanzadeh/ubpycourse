from flask import Flask, render_template, request
import requests
app = Flask(__name__)
@app.route('/')
def upload():
    return render_template('Input.html')
@app.route('/upload', methods=['GET','POST'])
def userupload():
    File = request.files['pic']
    File.save(File.filename)
    r = requests.post('https://api.imagga.com/v2/uploads',auth=('acc_c139eaa6a1339e4', '0cc8a6c34d773a3b4d585c68cba64721'),files={'image': open(File.filename, 'rb')}).json()['result']['upload_id']
    Answer = requests.get('https://api.imagga.com/v2/tags',auth=('acc_c139eaa6a1339e4', '0cc8a6c34d773a3b4d585c68cba64721'),params={'image_upload_id':r}).json()['result']['tags'][0]['tag']['en']
    Answer = requests.get('http://api.giphy.com/v1/gifs/search',  params={'q':Answer,'api_key': 'hoGFbzy4kDJHc4UGh6xugcw3BEQ1KZAd'}).json()['data']
    return render_template('Result.html', resp = [ Answer[i]['images']['fixed_height']['url'] for i in range(10) ])
if __name__ == '__main__':
    app.run(debug=True)
